
package com.example.imdcareerboard;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class DashboardActivity extends AppCompatActivity {
    Button appliedExamsBtn, paymentBtn, admitCardBtn, instructionsBtn, resultsBtn;
    TextView welcomeText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        welcomeText = findViewById(R.id.welcomeText);
        appliedExamsBtn = findViewById(R.id.appliedExamsBtn);
        paymentBtn = findViewById(R.id.paymentBtn);
        admitCardBtn = findViewById(R.id.admitCardBtn);
        instructionsBtn = findViewById(R.id.instructionsBtn);
        resultsBtn = findViewById(R.id.resultsBtn);

        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {
            String email = user.getEmail();
            welcomeText.setText("Welcome, " + email);
        }

        appliedExamsBtn.setOnClickListener(v -> Toast.makeText(this, "Applied Exams", Toast.LENGTH_SHORT).show());
        paymentBtn.setOnClickListener(v -> Toast.makeText(this, "Make Payment", Toast.LENGTH_SHORT).show());
        admitCardBtn.setOnClickListener(v -> Toast.makeText(this, "Download Admit Card", Toast.LENGTH_SHORT).show());
        instructionsBtn.setOnClickListener(v -> Toast.makeText(this, "Exam Instructions", Toast.LENGTH_SHORT).show());
        resultsBtn.setOnClickListener(v -> Toast.makeText(this, "Results Status", Toast.LENGTH_SHORT).show());
    }
}
