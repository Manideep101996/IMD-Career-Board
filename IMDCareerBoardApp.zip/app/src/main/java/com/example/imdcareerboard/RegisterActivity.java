
package com.example.imdcareerboard;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;

public class RegisterActivity extends AppCompatActivity {
    EditText name, email, phone, password;
    Button registerBtn;
    TextView goToLogin;
    FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        name = findViewById(R.id.name);
        email = findViewById(R.id.email);
        phone = findViewById(R.id.phone);
        password = findViewById(R.id.password);
        registerBtn = findViewById(R.id.registerBtn);
        goToLogin = findViewById(R.id.goToLogin);
        auth = FirebaseAuth.getInstance();

        registerBtn.setOnClickListener(v -> {
            String e = email.getText().toString();
            String p = password.getText().toString();
            auth.createUserWithEmailAndPassword(e, p).addOnSuccessListener(task -> {
                Toast.makeText(this, "Registered Successfully", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this, LoginActivity.class));
                finish();
            }).addOnFailureListener(e1 ->
                Toast.makeText(this, "Register Failed: " + e1.getMessage(), Toast.LENGTH_SHORT).show()
            );
        });

        goToLogin.setOnClickListener(v ->
            startActivity(new Intent(this, LoginActivity.class))
        );
    }
}
